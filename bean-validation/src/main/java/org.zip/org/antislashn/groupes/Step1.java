package org.antislashn.groupes;

public interface Step1 {

}
