package org.antislashn.groupes;

public interface Step3 {

}
